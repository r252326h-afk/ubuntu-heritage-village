UBUNTU HERITAGE VILLAGE — WEBSITE

WEBSITE PAGES
- index.html       Home page
- about.html       About Ubuntu Heritage Village, vision, mission and values
- experiences.html Cultural experiences and visitor itinerary planner
- community.html   Community participation and suggestions
- contact.html     Contact details and email enquiry form
- css/style.css    Responsive website styling
- js/script.js     Navigation, interactive sections, itinerary planner and forms

HOW TO OPEN THE WEBSITE
1. Extract the ZIP file into a folder.
2. Open index.html in a modern web browser such as Chrome, Edge or Firefox.
3. Use the navigation menu to explore the website.

CONTACT DETAILS
Location: Waterfalls, Harare, Zimbabwe
Email: simbachenga@gmail.com
Opening hours: 8:00 AM – 5:00 PM

NOTES
The contact enquiry form prepares an email in the visitor's default email application.
The visitor itinerary planner calculates estimated activity time. It does not reserve
a visit automatically. Contact the team directly to discuss visit arrangements.
